#include<iostream>
#include<sstream>
#include<algorithm>
#include<iomanip>
typedef long long ll;
using namespace std;
const int add_mod = 65536;
const int mul_mod = 65537;

//�������㣬���������Ϊ16λ�ַ���
unsigned int trans(string t)//16λ�ַ���תΪ��Ӧ������
{
	if (t == "0000000000000000")
		return 65536;
	unsigned int temp = 0;
	for (int i = 15; i >= 0; i--)
	{
		temp += (t[i] - '0') * pow(2, 15 - i);
	}
	return temp;
}
string trans(unsigned int t)//����תΪ16λ�ַ���
{
	string s;
	if (t >= 65536)
		return"0000000000000000";
	while (t != 0)
	{
		s += char(t % 2+'0');
		t /= 2;
	}
	reverse(s.begin(), s.end());
	stringstream ss;
	ss << setw(16) << setfill('0') << right << s;
	return ss.str();
}
string yihuo (string a, string b)//���
{
	string c="";
	for (int i = 0; i < 16; i++)
	{
		if (a[i] == b[i])
			c += '0';
		else
			c += '1';
	}
	return c;
}
string add(string a, string b)//ģ��
{
	unsigned int t = trans(a) + trans(b);
	t = t % add_mod;
	string s = trans(t);
	return s;
}
string mul(string a, string b)//ģ��
{
	long long a1 = trans(a)==0?(1<<16):trans(a);
	long long a2 = trans(b)==0?(1<<16):trans(b);
	unsigned int a3 = (a1 * a2)%mul_mod;
	return trans(a3);
}
//��Կ��չ
string key[60];
string my = "01001010101100101010110010101011001010101100101010110010101000001100101010110010101011001010101100101010110010101011001010100000";
string roll_left(string t)//128������Կѭ������25λ
{
	string s = t;
	for (int i = 0; i < t.length(); i++)
	{
		t[i] = s[(i + 25)%128];
	}
	return t;
}
void extend(string t)//�������128������Կ��չΪ52��16���ص�����Կ
{
	int i;
	for (i = 0; i < 6; i++)
	{
		key[i * 8 + 1] = t.substr(0, 16);
		key[i * 8 + 2] = t.substr(16, 16);
		key[i * 8 + 3] = t.substr(32, 16);
		key[i * 8 + 4] = t.substr(48, 16);
		key[i * 8 + 5] = t.substr(64, 16);
		key[i * 8 + 6] = t.substr(80, 16);
		key[i * 8 + 7] = t.substr(96, 16);
		key[i * 8 + 8] = t.substr(112, 16);
		roll_left(t);
	}
	key[i * 8 + 1] = t.substr(0, 16);
	key[i * 8 + 2] = t.substr(16, 16);
	key[i * 8 + 3] = t.substr(32, 16);
	key[i * 8 + 4] = t.substr(48, 16);
}
//���ܹ���
string idea_round(string t,int i)//��i�ּ��ܡ���64��������64�������
{
	string x1, x2, x3, x4, w1, w2, w3, w4,z1,z2,z3,z4,z5,z6;
	x1 = t.substr(0, 16), x2 = t.substr(16, 16), x3 = t.substr(32, 16), x4 = t.substr(48, 16);//4��16��������
	z1 = key[(i-1) * 6 + 1], z2 = key[(i - 1) * 6 + 2], z3 = key[(i - 1) * 6 + 3], z4 = key[(i - 1) * 6 + 4], z5 = key[(i - 1) * 6 + 5], z6 = key[(i - 1) * 6 + 6];//6��16������Կ
	string t1, t2, t3, t4, t5, t6, t7, t8, t9, t10;
	t1 = mul(x1, z1);
	t2 = add(x2, z2);
	t3 = add(x3, z3);
	t4 = mul(x4, z4);

	t5 = yihuo(t1, t3);
	t6 = yihuo(t2, t4);
	t7 = mul(t5, z5);
	t8 = add(t6, t7);
	t9 = mul(t8, z6);
	t10 = add(t7, t9);
	w1 = yihuo(t1, t9);
	w2 = yihuo(t9, t3);
	w3 = yihuo(t2, t10);
	w4 = yihuo(t10, t4);
	return w1 + w2 + w3 + w4;
}
string out_trans(string t)//����任
{
	string x1, x2, x3, x4;
	x1 = t.substr(0, 16), x2 = t.substr(16, 16), x3 = t.substr(32, 16), x4 = t.substr(48, 16);//4��16��������
	string y1, y2, y3, y4;
	y1 = mul(x1, key[49]);
	y2 = add(x3, key[50]);
	y3 = add(x2, key[51]);
	y4 = mul(x4, key[52]);
	return y1 + y2 + y3 + y4;
}
string IDEA(string X)//����
{
	extend(my);
	for (int i = 1; i <= 8; i++)
	{
		X = idea_round(X, i);
	}
	X = out_trans(X);
	return X;
}

//����
string key2[60];
void exgcd(ll a, ll b, ll& d, ll& x, ll& y)
{
	if (!b) { d = a; x = 1; y = 0; }
	else { exgcd(b, a % b, d, y, x); y -= x * (a / b); }
}
unsigned int inv(ll a, ll p)//��aģp�ĳ˷���Ԫ
{
	ll d, x, y;
	exgcd(a, p, d, x, y);
	return d == 1 ? (x + p) % p : -1;
}
unsigned int add_ni(ll a, ll p)//��aģp�ļӷ���Ԫ
{
	ll b = -a;
	if (b < 0)
		b += p;
	return b;
}
void dkey()//ͨ��������Կ��ý�����Կ
{
	for (int i = 1; i <= 9; i++)
	{
		for (int j = 1; j <= 4; j++)
		{
			int t = 6 * (10 - i - 1) + j;
			if(j==1||j==4)
				key2[(i-1)*6+j] = trans(inv(trans(key[t]),pow(2,16)+1));
			else
			{
				if (i == 1 || i == 9)
				{
					key2[(i - 1) * 6 + j] = trans(add_ni(trans(key[t]), pow(2, 16)));
				}
				else
				{
					if (j == 2)
						key2[(i - 1) * 6 + j] = trans(add_ni(trans(key[t + 1]), pow(2, 16)));
					else
						key2[(i - 1) * 6 + j] = trans(add_ni(trans(key[t - 1]), pow(2, 16)));
				}
			}
		}
	}
	for (int i = 1; i <= 8; i++)
	{
		key2[(i - 1) * 6 + 5] = key[(9 - i - 1) * 6 + 5];
		key2[(i - 1) * 6 + 6] = key[(9 - i - 1) * 6 + 6];
	}
}
string jiemi_round(string t, int i)//��i�ֽ��ܡ���64��������64�������
{
	string x1, x2, x3, x4, w1, w2, w3, w4, z1, z2, z3, z4, z5, z6;
	x1 = t.substr(0, 16), x2 = t.substr(16, 16), x3 = t.substr(32, 16), x4 = t.substr(48, 16);//4��16��������
	z1 = key2[(i - 1) * 6 + 1], z2 = key2[(i - 1) * 6 + 2], z3 = key2[(i - 1) * 6 + 3], z4 = key2[(i - 1) * 6 + 4], z5 = key2[(i - 1) * 6 + 5], z6 = key2[(i - 1) * 6 + 6];//6��16������Կ
	string t1, t2, t3, t4, t5, t6, t7, t8, t9, t10;
	t1 = mul(x1, z1);
	t2 = add(x2, z2);
	t3 = add(x3, z3);
	t4 = mul(x4, z4);

	t5 = yihuo(t1, t3);
	t6 = yihuo(t2, t4);
	t7 = mul(t5, z5);
	t8 = add(t6, t7);
	t9 = mul(t8, z6);
	t10 = add(t7, t9);
	w1 = yihuo(t1, t9);
	w2 = yihuo(t9, t3);
	w3 = yihuo(t2, t10);
	w4 = yihuo(t10, t4);
	return w1 + w2 + w3 + w4;
}
string out_trans2(string t)//����任
{
	string x1, x2, x3, x4;
	x1 = t.substr(0, 16), x2 = t.substr(16, 16), x3 = t.substr(32, 16), x4 = t.substr(48, 16);//4��16��������
	string y1, y2, y3, y4;
	y1 = mul(x1, key2[49]);
	y2 = add(x3, key2[50]);
	y3 = add(x2, key2[51]);
	y4 = mul(x4, key2[52]);
	return y1 + y2 + y3 + y4;
}
string jiemi(string X)//����
{
	dkey();
	for (int i = 1; i <= 8; i++)
	{
		X = jiemi_round(X, i);
	}
	X=out_trans2(X);
	return X;
}
int main()
{
	string X = "1111111111111111100000000001111111111111111111111111111111111111";
	string miwen = IDEA(X);
	string mingwen = jiemi(miwen);
	cout << "���ģ�" << X << endl;
	cout << "���ģ�" << miwen << endl;
	cout << "���ܣ�" << mingwen;
	
}